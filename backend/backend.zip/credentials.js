exports.creds = {
  did: "did:ethr:0xaa0e19a0a439516ba0acdcf076e9ee51524b93b4",
  privateKey: "2f227f6bd08a0e9833bf2151edff87a18b5a97b4d5cff7c071ab4614b21fb1e9"
}